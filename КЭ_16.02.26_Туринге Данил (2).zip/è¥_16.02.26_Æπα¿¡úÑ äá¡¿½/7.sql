SELECT screen, COUNT(*) as session_count 
FROM showings 
GROUP BY screen;
