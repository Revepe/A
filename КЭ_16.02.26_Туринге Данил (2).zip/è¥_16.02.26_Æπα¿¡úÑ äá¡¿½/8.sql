INSERT INTO showings (movie_id, screen, start_time, available_seats) 
VALUES (999, 'Hall 1', '12:00', 100);
