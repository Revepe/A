SELECT s.*, m.title 
FROM showings s
LEFT JOIN movies m ON s.movie_id = m.movie_id
WHERE m.title IS NULL;