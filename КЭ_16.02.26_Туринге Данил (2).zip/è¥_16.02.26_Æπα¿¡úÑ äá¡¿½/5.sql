UPDATE showings SET available_seats = 200 WHERE showing_id = 3;
