SELECT * FROM showings WHERE screen = 'IMAX';
