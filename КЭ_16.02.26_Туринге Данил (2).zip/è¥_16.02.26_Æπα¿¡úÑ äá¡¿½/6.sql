DELETE FROM showings WHERE showing_id = 7;
