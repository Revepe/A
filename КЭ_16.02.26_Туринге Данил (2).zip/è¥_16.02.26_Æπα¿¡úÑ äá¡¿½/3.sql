SELECT m.movie_id, m.title, m.director, m.duration, m.release_year,
       s.showing_id, s.screen, s.start_time, s.available_seats
INTO long_movies
FROM movies m
LEFT JOIN showings s ON m.movie_id = s.movie_id
WHERE m.duration > 150;
